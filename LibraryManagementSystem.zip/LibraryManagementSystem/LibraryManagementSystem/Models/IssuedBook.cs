﻿using System;

namespace LibraryManagementSystem.Models
{
    public class IssuedBook
    {
        public int Id { get; set; }
        public int BookId { get; set; }
        public Book Book { get; set; } 
        public string Borrower { get; set; } 
        public DateTime IssuedDate { get; set; }
    }
}
