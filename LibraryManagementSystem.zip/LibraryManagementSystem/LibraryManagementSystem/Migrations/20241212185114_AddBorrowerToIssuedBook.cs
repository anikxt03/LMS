﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibraryManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddBorrowerToIssuedBook : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReturnDate",
                table: "IssuedBooks");

            migrationBuilder.RenameColumn(
                name: "IssuedTo",
                table: "IssuedBooks",
                newName: "Borrower");

            migrationBuilder.RenameColumn(
                name: "IssueDate",
                table: "IssuedBooks",
                newName: "IssuedDate");

            migrationBuilder.CreateIndex(
                name: "IX_IssuedBooks_BookId",
                table: "IssuedBooks",
                column: "BookId");

            migrationBuilder.AddForeignKey(
                name: "FK_IssuedBooks_Books_BookId",
                table: "IssuedBooks",
                column: "BookId",
                principalTable: "Books",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_IssuedBooks_Books_BookId",
                table: "IssuedBooks");

            migrationBuilder.DropIndex(
                name: "IX_IssuedBooks_BookId",
                table: "IssuedBooks");

            migrationBuilder.RenameColumn(
                name: "IssuedDate",
                table: "IssuedBooks",
                newName: "IssueDate");

            migrationBuilder.RenameColumn(
                name: "Borrower",
                table: "IssuedBooks",
                newName: "IssuedTo");

            migrationBuilder.AddColumn<DateTime>(
                name: "ReturnDate",
                table: "IssuedBooks",
                type: "datetime(6)",
                nullable: true);
        }
    }
}
