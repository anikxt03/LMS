using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LibraryManagementSystem.Pages.Books
{
    public class CreateModel : PageModel
    {
        private readonly LibraryContext _context;

        public CreateModel(LibraryContext context)
        {
            _context = context;
        }

        
        [BindProperty]
        public Book Book { get; set; } = new Book();  

        
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            
            Book.AvailableCopies = Book.TotalCopies;

            
            _context.Books.Add(Book);
            _context.SaveChanges();

            
            return RedirectToPage("./Index");
        }
    }
}
