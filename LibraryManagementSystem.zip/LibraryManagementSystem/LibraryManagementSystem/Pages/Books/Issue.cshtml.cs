using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementSystem.Pages.Books
{
    public class IssueModel : PageModel
    {
        private readonly LibraryContext _context;

        public IssueModel(LibraryContext context)
        {
            _context = context;
        }

        
        public List<Book> Books { get; set; }

        [BindProperty]
        public int BookId { get; set; }

        [BindProperty]
        public string Borrower { get; set; }

        public void OnGet()
        {
           
            Books = _context.Books.ToList();
        }

        public IActionResult OnPost()
        {
            var book = _context.Books.FirstOrDefault(b => b.Id == BookId);
            if (book == null || book.AvailableCopies <= 0)
            {
                ModelState.AddModelError(string.Empty, "Book is not available.");
                return Page();
            }

            
            book.AvailableCopies--;
            _context.IssuedBooks.Add(new IssuedBook
            {
                BookId = BookId,
                Borrower = Borrower,
                IssuedDate = DateTime.Now
            });

            _context.SaveChanges();
            return RedirectToPage("./Index");
        }
    }
}
