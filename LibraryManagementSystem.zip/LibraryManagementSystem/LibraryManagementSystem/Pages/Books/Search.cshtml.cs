using Microsoft.AspNetCore.Mvc.RazorPages;
using LibraryManagementSystem.Models;
using System.Linq;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem.Pages.Books
{
    public class SearchModel : PageModel
    {
        private readonly LibraryContext _context;

        public SearchModel(LibraryContext context)
        {
            _context = context;
        }

        public string Query { get; set; }

        public List<Book> Results { get; set; } = new List<Book>();

        public void OnGet(string query)
        {
            Query = query;
            if (!string.IsNullOrEmpty(Query))
            {
                Results = _context.Books
                    .Where(b => b.Title.Contains(Query) || b.Author.Contains(Query))
                    .ToList();
            }
        }
    }
}
