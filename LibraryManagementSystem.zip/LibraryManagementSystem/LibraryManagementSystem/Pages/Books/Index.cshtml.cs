using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Pages.Books
{
    public class IndexModel : PageModel
    {
        private readonly LibraryContext _context;

        public IndexModel(LibraryContext context)
        {
            _context = context;
        }

        public IList<Book> Books { get; set; }

        public async Task OnGetAsync(string searchQuery)
        {
            if (string.IsNullOrEmpty(searchQuery))
            {
                Books = await _context.Books.ToListAsync();
            }
            else
            {
                Books = await _context.Books
                    .Where(b => b.Title.Contains(searchQuery) || b.Author.Contains(searchQuery))
                    .ToListAsync();
            }
        }
    }
}
