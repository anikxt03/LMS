using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using System.Linq;

namespace LibraryManagementSystem.Pages.Books
{
    public class ReturnModel : PageModel
    {
        private readonly LibraryContext _context;

        public ReturnModel(LibraryContext context)
        {
            _context = context;
        }

        
        public List<IssuedBook> IssuedBooks { get; set; }

        [BindProperty]
        public int IssuedBookId { get; set; }

        public void OnGet()
        {
           
            IssuedBooks = _context.IssuedBooks
                .Include(ib => ib.Book) 
                .ToList();
        }

        public IActionResult OnPost()
        {
            
            var issuedBook = _context.IssuedBooks.FirstOrDefault(ib => ib.Id == IssuedBookId);
            if (issuedBook == null)
            {
                ModelState.AddModelError(string.Empty, "Issued book not found.");
                return Page();
            }

            
            var book = _context.Books.FirstOrDefault(b => b.Id == issuedBook.BookId);
            if (book != null)
            {
                book.AvailableCopies++;
            }

            
            _context.IssuedBooks.Remove(issuedBook);
            _context.SaveChanges();

            return RedirectToPage("./Index");
        }
    }
}
