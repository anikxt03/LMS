using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LibraryManagementSystem.Pages.Books
{
    public class DeleteModel : PageModel
    {
        private readonly LibraryContext _context;

        public DeleteModel(LibraryContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Book Book { get; set; }

        public void OnGet(int id)
        {
            Book = _context.Books.FirstOrDefault(b => b.Id == id);
        }

        public IActionResult OnPost()
        {
            _context.Books.Remove(Book);
            _context.SaveChanges();
            return RedirectToPage("./Index");
        }
    }
}
